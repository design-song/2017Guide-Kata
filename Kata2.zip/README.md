# 중요한 사항

## 프로젝트 개요

* 2017 삼성SDS 알고리즘 경진대회를 위한 프로젝트

## KataBot 개발 취지 및 특이사항

* 경진대회 결과물의 수준을 상향화 하기 위해 BasicBot 에 약간의 Kata 코드를 추가하여 연습용으로 제공함

* [먼저 BasicBot wiki 에서 개발환경 설정 방법, 튜터리얼 및 가이드를 읽어본 후 개발하는 것을 권장함](https://github.com/SamsungSDS-Contest/2017Guide/wiki)

